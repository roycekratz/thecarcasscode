export default async function handler(req, res) {
  try {
    const response = await fetch("https://mymarketnews.ams.usda.gov/api/reports/get?id=2291", {
      headers: {
        "Accept": "application/json",
        "User-Agent": "Mozilla/5.0"
      }
    });

    if (!response.ok) {
      throw new Error(`USDA responded with status ${response.status}`);
    }

    const data = await response.json();
    res.status(200).json(data);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
}

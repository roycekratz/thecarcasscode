import { useEffect, useState } from "react";

export default function Home() {
  const [usdaData, setUsdaData] = useState(null);
  const [species, setSpecies] = useState("all");
  const [date, setDate] = useState("");

  useEffect(() => {
    fetch("/api/usda-prices")
      .then((res) => res.json())
      .then(setUsdaData)
      .catch((err) => console.error("USDA fetch error:", err));
  }, []);

  const filteredEntries = usdaData
    ? Object.entries(usdaData).filter(([key, val]) => {
        // Filter by species
        if (species !== "all" && !key.toLowerCase().includes(species)) {
          return false;
        }
        // Filter by date
        if (date && val.date) {
          return val.date.startsWith(date);
        }
        return true;
      })
    : [];

  return (
    <main style={{ padding: "2rem", fontFamily: "sans-serif" }}>
      <h1>The Carcass Code</h1>
      <p>This is the homepage of your USDA-integrated meat pricing platform.</p>

      <section>
        <h2>📈 Market Prices</h2>
        <label style={{ marginRight: "1rem" }}>
          Species:
          <select
            value={species}
            onChange={(e) => setSpecies(e.target.value)}
            style={{ margin: "0 0.5rem" }}
          >
            <option value="all">All</option>
            <option value="beef">Beef</option>
            <option value="pork">Pork</option>
            <option value="lamb">Lamb</option>
          </select>
        </label>
        <label>
          Date:
          <input
            type="date"
            value={date}
            onChange={(e) => setDate(e.target.value)}
            style={{ margin: "0 0.5rem" }}
          />
        </label>

        <div style={{ marginTop: "1rem" }}>
          {usdaData ? (
            <ul>
              {filteredEntries.map(([key, val]) => (
                <li key={key} style={{ marginBottom: "0.5rem" }}>
                  <strong>{key}:</strong> ${val.price ?? val}
                  {val.date && <em> ({val.date})</em>}
                </li>
              ))}
            </ul>
          ) : (
            <p>Loading market data…</p>
          )}
        </div>
      </section>

      <section style={{ marginTop: "2rem" }}>
        <h2>📷 Program & Brand Logos</h2>
        <div
          style={{
            display: "flex",
            gap: "1rem",
            flexWrap: "wrap",
            alignItems: "center",
          }}
        >
          <img src="/brands/cab.png" alt="Certified Angus Beef" width="120" />
          <img
            src="/brands/chairmans-reserve.png"
            alt="Chairman's Reserve"
            width="120"
          />
          <img
            src="/brands/sterling-silver.png"
            alt="Sterling Silver"
            width="120"
          />
          <img src="/brands/swift-1855.png" alt="Swift 1855" width="120" />
          <img
            src="/brands/seaboard-prime-pork.png"
            alt="Seaboard Prime Pork"
            width="120"
          />
          <img src="/brands/ibp.png" alt="IBP" width="120" />
          <img
            src="/brands/smithfield.png"
            alt="Smithfield / Farmland"
            width="120"
          />
        </div>
      </section>
    </main>
  );
}
